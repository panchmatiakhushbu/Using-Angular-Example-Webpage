import { Component, OnInit } from '@angular/core';
import * as AOS from 'aos';

@Component({
  selector: 'app-main',
  templateUrl: './main.component.html',
  styleUrls: ['./main.component.css']
})
export class MainComponent implements OnInit {


  constructor() { }

  ngOnInit() {
    AOS.init({
      duration: 1200,
    })
  }

  /*Expert slider js start*/
  public bannerslider ={
     autoplay:true,
     autoplaySpeed:4000,
     speed:2000,
     slidesToShow:1,
     slidesToScroll:1,
     pauseOnHover:false,     
     pauseOnDotsHover:true,      
     draggable:true,
     arrows:false,     
     responsive: [
      {
        breakpoint: 991,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,   
        }
      },
      {
        breakpoint: 600,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,         
        }
      }    
    ]    
  };

  /*Expert slider js end*/

  /*Blog slider js start*/


  public blogslider ={
    autoplay:true,
    autoplaySpeed:4000,
    speed:2000,
    slidesToShow:3,
    slidesToScroll:1,
    pauseOnHover:false,     
    pauseOnDotsHover:true,      
    draggable:true,
    arrows:false,     
    responsive: [
     {
       breakpoint: 991,
       settings: {
         slidesToShow: 2,
         slidesToScroll: 1,          
         dots: true,   
       }
     },
     {
       breakpoint: 600,
       settings: {
         slidesToShow: 1,
         slidesToScroll: 1,
         dots: true, 
       }
     }    
   ]    
 };
  /*Blog slider js end*/

}
